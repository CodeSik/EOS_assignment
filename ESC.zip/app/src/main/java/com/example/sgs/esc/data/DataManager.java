package com.example.sgs.esc.data;

import java.util.ArrayList;

/**
 * Created by dydnr on 2016-08-03.
 */
public class DataManager {
    private static ArrayList<PersonInfo> list = new ArrayList<>();

    public static ArrayList<PersonInfo> getList(){
        if(list.size() == 0){
            list.add(new PersonInfo("건식", "01054248706", "iqeq2328@gmail.com"));
            return list;
        }else{
            return list;
        }

    }
}