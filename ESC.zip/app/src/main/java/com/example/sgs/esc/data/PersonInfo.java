package com.example.sgs.esc.data;

/**
 * Created by dydnr on 2016-08-03.
 */
public class PersonInfo {
    private String name, phone, email;

    public PersonInfo (String name, String phone, String email){
        this.name = name;
        this.phone = phone;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }
}