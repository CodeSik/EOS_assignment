package com.example.sgs.esc.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.sgs.esc.R;


/**
 * Created by dydnr on 2016-08-03.
 */
public class ItemVH extends RecyclerView.ViewHolder {
    TextView name, phone, email;
    Button call;
    View v;
    public ItemVH(View itemView) {
        super(itemView);
        v = itemView;
        name = (TextView)itemView.findViewById(R.id.item_name);
        phone = (TextView)itemView.findViewById(R.id.item_phone_num);
        email = (TextView)itemView.findViewById(R.id.item_email);
        call = (Button)itemView.findViewById(R.id.item_call);
    }
}