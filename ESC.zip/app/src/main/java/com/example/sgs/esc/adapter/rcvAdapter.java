package com.example.sgs.esc.adapter;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.sgs.esc.R;
import com.example.sgs.esc.data.DataManager;
import com.example.sgs.esc.data.PersonInfo;


/**
 * Created by dydnr on 2016-08-03.
 */
public class rcvAdapter extends RecyclerView.Adapter<ItemVH> {
    @Override
    public ItemVH onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recyclerview, parent, false);
        ItemVH itemVH = new ItemVH(view);
        return itemVH;
    }

    @Override
    public void onBindViewHolder(final ItemVH holder, int position) {
        final PersonInfo pi = DataManager.getList().get(position);
        holder.name.setText(pi.getName());
        holder.phone.setText(pi.getPhone());
        holder.email.setText(pi.getEmail());

        holder.call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = "tel" + pi.getPhone();
                Intent phoneCall = new Intent(Intent.ACTION_CALL);
                phoneCall.setData(Uri.parse("tel:"+pi.getPhone()));
                view.getContext().startActivity(phoneCall);
            }
        });
    }

    @Override
    public int getItemCount() {
        return DataManager.getList().size();
    }
}
