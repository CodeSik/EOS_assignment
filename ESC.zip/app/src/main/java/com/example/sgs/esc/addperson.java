package com.example.sgs.esc;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.sgs.esc.data.DataManager;
import com.example.sgs.esc.data.PersonInfo;

public class addperson extends AppCompatActivity {
    Button  add;
    EditText name,phone,email;
    @Override



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addperson1);
        add = (Button)findViewById(R.id.complete);
        name = (EditText)findViewById(R.id.name_write);
        phone = (EditText)findViewById(R.id.number_write);
        email = (EditText)findViewById(R.id.email_write);
        add.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                DataManager.getList().add(new PersonInfo(
                        name.getText().toString(),
                        phone.getText().toString(),
                        email.getText().toString()
                ));
                Intent intent = new Intent(addperson.this,com.example.sgs.esc.MainActivity.class);
                startActivity(intent);
                finish();

                }
            });
        }


    }

